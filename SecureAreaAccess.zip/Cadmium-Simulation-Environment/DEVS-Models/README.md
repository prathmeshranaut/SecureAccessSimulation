# Cadmium-DEVS-Models
This is a parent repository containing a reference to Cadmium-DEVS models developed by ARSLab at Carleton University.


To *download all models* clone this repository and then run: 
> git submodule update --init --recursive

To *download an individual model* (ex, ABP) clone this repository and then run:
> git submodule update --init --remote --recursive -- ABP/

If it is your first time running a Cadmium model you need to setup your environment.

Instructions for setting up the environment can be found here:

****** 